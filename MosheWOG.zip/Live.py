## Moshe Barazani
## Date: 04-02-2020

def get_gamer_name():
    gamer_name = input("Welcome, enter your name: ")
    print("\nHello {gn} and welcome to the World of Games (WoG).\nHere you can find many cool games to play.\n".format(gn=gamer_name))
    return gamer_name

def load_game():
    print("Please choose a game to play:\n \
   1. Memory Game - a sequence of numbers will appear for 1 second and you have to guess it back\n \
   2. Guess Game - guess a number and see if you chose like the computer\n \
   3. Currency Roulette - try and guess the value of a random amount of USD in ILS\n \
   4. Seven Boom \n")
    games_name = ("Memory Game", "Guess Game", "Currency Roulette", "Seven Boom")
    game2paly = input("Choose your game: ")
    while (game2paly not in ["1","2","3","4"]):
        game2paly = input("Choose your game (1-4): ")
    game2palyInt = int(game2paly)-1
    return game2paly,games_name[game2palyInt]


def get_game_difficulty(game_name):
    game_difficulty = input("Please choose game difficulty for \"{gn}\" from 1 to 5: ".format(gn=game_name))
    while (game_difficulty not in ["1","2","3","4","5"]):
        game_difficulty = input("Choose game difficulty (1-5): ")
    return game_difficulty


def seven_boom():
    num = int(input("Enter Number: "))
    for x in range(num):
        x+=1
        if not (x % 7):
            print("BOOM!")
        else:
            if "7" in str(x):
                print("BOOM!")
            else:
                print(x)