## Moshe Barazani
## Date: 04-02-2020

from Live import *

gamer_name = get_gamer_name()
which_game2paly,game_name = load_game()

if (which_game2paly in ["1","2","3"]):
    #print("Game number: {gn}".format(gn=which_game2paly))
    get_difficulty = get_game_difficulty(game_name)
    print("You choose game number {gp} and difficulty number {dif}, good luck.".format(gp=which_game2paly, dif=get_difficulty))
else:
    seven_boom()
